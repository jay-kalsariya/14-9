import React from 'react'
import { useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux';
import { actionCreatore } from '../State/index';
import { useSelector } from "react-redux";

const Shop = () => {
  const dispatch = useDispatch();
  const balance = useSelector(state => state.amount)
  const {withdrawMoney,depositMoney} = bindActionCreators(actionCreatore,dispatch)
  return (
    <div >
     <h2>Deposit/withdraw money</h2>
<button className="btn btn-primary mx-2" onClick={()=>{withdrawMoney(100)}}>-</button>
        Update Balance ({balance})
<button className="btn btn-primary mx-2" onClick={()=>{depositMoney(100)}}>+</button>
    </div>
  )
}

export default Shop
