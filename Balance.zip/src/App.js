
import './App.css';
import Navbar from './componet/Navbar';
import Shop from './componet/Shop';


function App() {
  return (
   <>
    <Navbar/>
     <div className="container">
     <Shop />
    </div>
    </>
  );
}

export default App;
