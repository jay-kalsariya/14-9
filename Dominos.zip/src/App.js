// import "./App.css";
import Navbar from "./Compontes/Navbar";
import Home  from "./Page/Home";
import Menu from "./Page/Menu";
import About from "./Page/About";
import Contact from "../src/Page/Contact";
import From1 from    "./Page/From1";
import Login from "./Page/Login";
import Footer from "./Compontes/Footer";
import { Routes,Route} from "react-router-dom";

function App() {
  return (
   
    <div className="App">
    
        <Navbar />
        <Routes>
          
          <Route path="/Home" element={<Home/>} />
          <Route path="/menu" element={ <Menu/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path="/SignUp" element={<From1/>} />
          <Route path="/Login" element={<Login/>}/>
          </Routes>
          <Footer />
     
    
    </div>
  );
}

export default App;
