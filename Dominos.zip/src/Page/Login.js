import React from 'react';
import { useState } from 'react';
import "../Page/style/Login.css";


  const Login = () => {

    const [Uname,setuname]=useState("");
    // const [Email,setemail]=useState("");
    const [Password,setpassword]=useState("");
    const [all,setAll]=useState([]);





    const username=(e)=>{
      setuname(e.target.value)
  }

  // const email=(e)=>{
  //     setemail(e.target.value)
  // }
  const password=(e)=>{
      setpassword(e.target.value)
  }

  const handleSubmit=(e)=>{
    e.preventDefault();
    const newEntry ={username:Uname,password:Password};
    setAll ([...all,newEntry]);
    console.log(Uname);// aa Uname use karvani che
    // console.log(Email);// aa Email 
    console.log(Password);// aa Password

    setuname("");
    // setemail("");
    setpassword("");
  }

  
  return (
   
<div className='log'>

      <form onSubmit={handleSubmit}>  
        <h1>Login</h1>
       
        <div className="ui form">
          <div className="field">
            <label><b>Username:</b></label>
            <input
              type="text"
              className="form-control"
              id="username"
              placeholder="Username"
               value={Uname}
              onChange={username} />
          </div>
        
          {/* <div className="field">
            <label><b >Email:</b></label>
            <input
              type="text"
              className="form-control"
              id="email"
              placeholder="Email"
              value={Email}
              onChange={email}/>
          </div> */}
       
          <div className="field">
            <label><b>Password:</b></label>
            <input
              type="password"
              className="form-control"
              id="password"
            placeholder="Password"
               value={Password}
              onChange={password}/>
          </div>
       
          <button className="button">Submit</button>
        </div>
      </form>
    
      </div>
  );
}

export default Login;
