import React from 'react'
import Ptext  from './Ptext';

export default function Map() {
  return (
    <div>
      <div className="container">
        <div className="map__card">
            <h3 className="map__card__heading">Here is me</h3>
            <Ptext>GEC Circle,Adajan hanny park road surat</Ptext>
            <a href="https://www.google.com/maps/@21.2140032,72.8039424,13z" target="_blank" rel="noreferrer"> open in google Map</a>
        </div>
      </div>
    </div>
  )
}
