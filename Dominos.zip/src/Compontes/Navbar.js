import React from "react";
import Logo from "../assets/dp.jpg"
import { Link } from "react-router-dom";  
import download from "../assets/download.png";
import "../Page/style/Navbar.css";

function Navbar() {

  return (
    <div className="navbar">
      <nav className="navbar navbar-expand-lg navbar-blue bg-blue">
  <div className="container-fluid">
    <div className="Logo">
   <img src={Logo}/>
   <a><b>Dominos</b></a> 
    
  
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="manu" id="navbarNav">
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/Home">Home</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/Menu">Menu</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/About">About Us</Link>
        </li>
        <li className="nav-item">
        <Link className="nav-link" to="/Contact">Contact Us</Link>
        
        </li>
      </ul>
    </div>
  </div>
  </div>
</nav>
     <div className="prf-grf">
     
        <img src={download} className="profile"/>
        <div data-label="my-account" className="prf-grp-txt">
          MY ACCOUNT
 </div>
             <div className="sign">
            <Link to="/SignUp" className="nav-link">SignUp  </Link>
            
             <Link to ="/Login" className="nav-link">Login</Link> 
        
       </div>

      </div>

    </div>
  
  
  );
}

export default Navbar;